import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import datetime
import mplfinance as mpf
import pmdarima as pm

def SalesPlot():
    # Resample the data by month and sum the 'Sales' for each month

    # Create a line plot of the monthly sales
    df = pd.DataFrame(monthly_sales)
    fig, ax = plt.subplots()
    df.plot(ax=ax)
    plt.xlabel('Month')
    plt.ylabel('Sales')
    plt.title('Monthly Sales Trend')

    # Show the plot
    plt.show()

# print(data.head())
# print(data.isnull().any())

def ProfitPlot():
    # Resample the data by month and sum the 'Profit' for each month
    monthly_profits = data['Profit'].resample('M').sum()

    # Create a line plot of the monthly profits
    df = pd.DataFrame(monthly_profits)
    fig, ax = plt.subplots()
    df.plot(ax=ax)
    plt.xlabel('Month')
    plt.ylabel('Profit')
    plt.title('Monthly Profit Trend')

    # Show the plot
    plt.show()


def SalesCategory():

    # Group the data by 'Category' and resample it by month, summing the 'Sales' for each month
    monthly_sales_by_category = data.groupby('Category')['Sales'].resample('M').sum()
    # Reset the index
    monthly_sales_by_category = monthly_sales_by_category.reset_index()
    # Pivot the dataframe to get 'Category' as columns and 'Sales' as values
    df = monthly_sales_by_category.pivot(index='Order Date', columns='Category', values='Sales')
    # Create a line plot of the monthly sales for each category
    fig, ax = plt.subplots()
    df.plot(ax=ax)
    plt.xlabel('Month')
    plt.ylabel('Sales')
    plt.title('Monthly Sales by Category')
    plt.show()

def Predict(dt):
    # Fit the ARIMA model
    model = pm.auto_arima(dt, seasonal=True, m=12)
    # Make a forecast for the next 12 months
    forecast = model.predict(n_periods=12)
    # Print the forecast
    print(forecast)
    return forecast

def ForecastPlot(forecast, dt, text):
    # Create a range of future dates that is the length of the periods we forecasted
    future_dates = pd.date_range(dt.index[-1], periods = 13, freq='M').tolist()[1:]
    # Convert forecasted data into a pandas series
    forecast_series = pd.Series(forecast, index=future_dates)
    # Plot the sales data
    plt.figure(figsize=(10,6))
    plt.plot(dt)
    plt.plot(forecast_series, linestyle='--')
    plt.xlabel('Time')
    plt.ylabel(text)
    plt.title(f'{text} (Historical and Forecasted)')
    #plt.legend()
    plt.show()

def PredictSalesCategory():
    # Group the data by 'Category' and resample it by month, summing the 'Sales' for each month
    monthly_sales_by_category = data.groupby('Category')['Sales'].resample('M').sum()
    # Get the unique categories
    categories = data['Category'].unique()
    colors = {'Furniture': 'blue', 'Office Supplies': 'orange', 'Technology': 'green'}
    # Create a figure
    plt.figure(figsize=(10,6))
    # Loop over each category
    for i, category in enumerate(categories):
        # Fit the ARIMA model
        model_category = pm.auto_arima(monthly_sales_by_category[category], seasonal=True, m=12)
        # Make a forecast for the next 12 months
        forecast_category = model_category.predict(n_periods=12)
        # Create a range of future dates that is the length of the periods we forecasted
        future_dates_category = pd.date_range(monthly_sales_by_category[category].index[-1], periods = 13, freq='M').tolist()[1:]
        # Convert forecasted data into a pandas series
        forecast_series_category = pd.Series(forecast_category, index=future_dates_category)
        print(forecast_series_category)
        # Plot the sales data for the category
        plt.plot(monthly_sales_by_category[category], label=f'{category} - Historical', color=colors[category])
        plt.plot(forecast_series_category, label=f'{category} - Forecasted', linestyle='--', color=colors[category])

    plt.title('Sales by Category (Historical and Forecasted)')
    plt.xlabel('Month')
    plt.ylabel('Sales')
    plt.legend()
    plt.show()







if __name__ == "__main__":

    data = pd.read_excel('Superstore.xls', 'Orders')

    # Convert 'Order Date' to datetime format
    if data['Order Date'].dtype != 'datetime64[ns]':
        data['Order Date'] = pd.to_datetime(data['Order Date'])

    # Set 'Order Date' as the index of the dataframe
    data.set_index('Order Date', inplace=True)

    monthly_sales = data['Sales'].resample('M').sum()
    monthly_profits = data['Profit'].resample('M').sum()

    SalesPlot()
    ProfitPlot()
    SalesCategory()

    predicted_sales = Predict(monthly_sales)
    predicted_profits = Predict(monthly_profits)
    ForecastPlot(predicted_sales, monthly_sales, "Sales")
    ForecastPlot(predicted_profits, monthly_profits, "Profits")

    PredictSalesCategory()
